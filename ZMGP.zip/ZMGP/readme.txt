ZmodX Tweak 
Versi : 4.0 Stable

Install Via Brevent.

[+] Install.
sh /sdcard/ZMGP/Install[B].sh

[+] Uninstall.
sh /sdcard/ZMGP/Uninstall[B].sh

Install Via Termux.

[+] Salin satu persatu perintah dibawah.
pkg upgrade -y && pkg install bash -y && pkg install shc -y && pkg install binutils -y && termux-setup-storage
cd /sdcard/ZMGP && sh rish
sh setup.sh

[+] Membuka Menu Tweak Jika Sudah Melakukan Instalasi File Modul Dengan setup.sh
cd /sdcard/ZMGP && sh rish
cd /data/local/tmp
./ZMGP

Atau

rm -rf /data/local/tmp/* && cp /sdcard/ZMGP/ZMGP /data/local/tmp && chmod +x /data/local/tmp/ZMGP && /data/local/tmp/ZMGP

Harap Di Mengerti Apa Yang Sudah Saya Jelaskan !!
Untuk Cara Mengaktifkan Fitur" Masukkan Angka Yang Ingin Dipilih Dan Tekan Enter.

[+] Fitur-Fitur Yang Ada Didalam Tweak ->
- Sentuhan Lebih Responsif
- Aktifkan Mode Kecepatan
- Mengoptimalkan Kinerja
- Interval FSTRIM
- Zram
- Memperbaiki Sentuhan Delay
- Mengoptimalkan FPS
- Penguat CPU & GPU
- Nonaktifkan joyose Xiaomi
- Layanan Termal
- Pengurangan Frame Drop di Semua Game
- Meningkatkan Kualitas Pengalaman Bermain Game
- Meningkatkan Performa Game
- Tingkatkan Kinerja Di Perangkat No Root

Catatan !!
- Modul Bersifat Universal Jadi Support Semua Device & Bisa Dicombo Dengan Modul Lain.
- Jika Mengalami Masalah Seperti BlackScreen,Mulai Ulang Sendiri / Perangkat Terasa Berat
  Jalankan Ulang Modul Di Termux Lalu Pilih Angka 2.Uninstall >> ZModXTweak.
- Jika Perangkat Tidak Mendukung Beberapa Rendering Seperti Mengalami Aplikasi Keluar Sendiri
  Untuk Cara Mengatasi Nya Tinggal Reboot Perangkat.

Changelog & Fix !!
Versi 2.0
- Menambahkan Fitur Baru (Rendering)
- Penampilan baru
- Pembaruan tweak
- Memuat lebih cepat
Versi 3.0
- Memuat Script Lebih Cepat
- Memperbaiki Error / Bug Di Versi Sebelumnya
- Pembaruan Script Tweak
Versi 4.0
- Memperbaiki Kesalahan Tombol Navigasi Tidak Bisa Di Pencet
- Pembaruan Script Tweak
- Tampilan Lebih Simple Dan Elegan

Masukan / Saran !!
Bisa Langsung DM Saya Di Telegram @jjogit
Telegram @ZmodX
2023