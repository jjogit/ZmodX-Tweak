ZmodX Tweak 
Versi : 1 Final Universal

Command Instal With Termux :
Shizuku's permission >>
sh /sdcard/ZXT/rish

Run Command Script >>
rm -rf /data/local/tmp/* && cp /sdcard/ZXT/ZmodX /data/local/tmp && chmod +x /data/local/tmp/ZmodX && /data/local/tmp/ZmodX

Run Command Script 32 BIT >>
sh /sdcard/ZXT/install32-bit.sh

Jika Muncul Kesalahan Seperti Dibawah :
~ $ sh /sdcard/ZXT/rish
Request timeout. The connection between the current app (com.
termux) and Shizuku app may be blocked by your system. Please di
sable all battery optimization features for both current app
(com.termux) and Shizuku app.

Buka Brevent / LADB Lalu Masukkan Command Seperti Dibawah :
sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh

Harap Di Mengerti Apa Yang Sudah Saya Jelaskan !!
Untuk Cara Mengaktifkan Fitur" Masukkan Angka Yang Ingin Dipilih Dan Tekan Enter.

Fitur-Fitur Yang Ada Didalam Tweak >>
- Responsive Touch    
- Enable Speed Mode
- Optimizing Performance
- FSTRIM Interval
- Game Dashboard
- Fixed Ghost Touch
- Optimizing FPS
- CPU & GPU Booster
- Disable joyose Xiaomi
- Thermal Service
- GPUTUNER
- CPUTUNER
- Reduced Frame Drop in All Games.
- Improving the Quality of the Game Playing Experience.
- Disable Hwaac
- Improve Performance On No Root Devices

Catatan !!
- Modul Bersifat Universal Jadi Support Semua Device & Bisa Dicombo Dengan Modul Lain.
- Jika Mengalami Masalah Seperti BlackScreen / Mulai Ulang Sendiri
  Jalankan Ulang Modul Di Termux Lalu Pilih Angka 2.Uninstall >> ZModXTweak.

Kekurangan Dari Modul ZModXTweak !!
- Akan Sedikit Boros Baterai
- Device Bisa Lebih Hangat

Masukan / Saran !!
Bisa Langsung DM Saya Di Telegram @jjogit (Spesn | Peli Cuk)
Telegram @ZmodX
2023